<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/login', function(){
    return view('login');
    // menambahkan /login pada url kemudian akan mereturn view dan akan mengambil view login
});

Route::post('/login', function(Request $request){
    dd($request);
});

Route::get('/test2', function(){
    return "Laravel test view 2";
});
Route::redirect('/test1', '/test2');

// Route::name('admin')->group(function (){
//     Route::get('user', function(){
//         //
//     })->name('user');
// });

// Route::domain('{account}.myapp.com')->group(function (){
//     Route::get('user/{id}',function ()($account, $id){
//         //
//     });
// });

// Route::namespace('admin')->group(function (){
//     //
// });

// Route::middleware(['first','second'])->group(function (){
//     Route::get('/', function (){
//         //
//     });
//     Route::get('user/profile',function(){
//         //
//     });
// });


// public function handle($request, Closure $next)
// {
//     if($request->Route()->named('profile')){
//         //
//     }
//     return $next($request);
// }

// Route::get('user/{id}/profile' , function ($id){
//     //
// })->name('profile');
// $url=Route('profle' , ['id' => 1 , 'photos' => 'yes']);

// $url = route('profile');
// return redirect()->route('profile');

// Route::get('search/{search}', function ($search){
//     return $search;
// })->where('search', '.*');

// Route::get('user/{name}', function ($name){
//     //
// })-> where('name', '[A-Za-z]+');
// Route::get('user/{id}', function ($id){
//     //
// })->where('id', '[0-9]+');
// Route::get('user/{id}/{name}', function {$id, $name}{
//     //
// })where(['id' => '[0-9]' , 'name' => '[a-z]+']);

// Route::get('user/{name?}', function ($name = null){
//     return $name;
// });
// Route::get('user/{name?}' , function ($name = 'John'){
//     return $name;
// });

Route::view('/welcome','test1');
// Route::view('/welcome','welcome', ['name' => 'Taylor']);

// Route::permanentRedirect('/here', '/there');

// Route::match(['get','post'], '/', function () {
//     //
// });

// Route::any('/',function(){
//     //
// });

// Route::get($uri, $callback);
// Route::post($uri,$callback);
// Route::put($uri,$callback);
// Route::patch($uri,$callback);
// Route::delete($uri,$callback);
// Route::options($uri,$callback);

// Route::get('/user', 'UserController@index');
