<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>test route</title>
</head>
<body>
    <h1>hello world</h1>
    <h2>Namaku Muhammad Reza Ivano Pahlevi</h2>
    <p>lorem pesum</p>
</body>
</html>
<?php /**PATH E:\! KULIAHHH\Ivano Kuliah\!SEMESTER 4\WS WEB\Minggu 1\testbuuatlaravel\testMembuatLaravel\resources\views/test1.blade.php ENDPATH**/ ?>